create
    definer = root@localhost procedure getCustomerCountByCity(IN in_city varchar(50), OUT total int)
begin
    select count(customerNumber) into total
    from customers
    where city = in_city;
end;

